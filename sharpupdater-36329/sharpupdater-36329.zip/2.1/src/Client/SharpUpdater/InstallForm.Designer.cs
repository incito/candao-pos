﻿namespace CnSharp.Windows.Updater
{
	partial class InstallForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      SingleAssemblyComponentResourceManager resources = new SingleAssemblyComponentResourceManager(typeof(InstallForm));
      this.lblStatus = new System.Windows.Forms.Label();
      this.progressBar1 = new System.Windows.Forms.ProgressBar();
      this.SuspendLayout();
      // 
      // lblStatus
      // 
      resources.ApplyResources(this.lblStatus, "lblStatus");
      this.lblStatus.Name = "lblStatus";
      // 
      // progressBar1
      // 
      resources.ApplyResources(this.progressBar1, "progressBar1");
      this.progressBar1.Name = "progressBar1";
      // 
      // InstallForm
      // 
      resources.ApplyResources(this, "$this");
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.Controls.Add(this.progressBar1);
      this.Controls.Add(this.lblStatus);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "InstallForm";
      this.Load += new System.EventHandler(this.ConnectionFormLoad);
      this.ResumeLayout(false);
      this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblStatus;
		private System.Windows.Forms.ProgressBar progressBar1;
	}
}