﻿namespace CnSharp.Windows.Updater.SharpPack
{
    public class ProductInfo
    {
        public string Name { get; set; }

        public string CompanyName { get; set; }

        public string Version { get; set; }
    }
}
