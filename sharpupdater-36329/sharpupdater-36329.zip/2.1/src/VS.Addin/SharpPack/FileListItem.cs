﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CnSharp.Windows.Updater.SharpPack
{
    public class FileListItem
    {
        public string Dir { get; set; }
        public bool IsFile { get; set; }
        public bool Selected { get; set; }
    }
}
