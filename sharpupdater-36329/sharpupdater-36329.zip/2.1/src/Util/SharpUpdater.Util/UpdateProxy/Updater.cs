﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CnSharp.Windows.Updater.Util.UpdateProxy
{
    public class Updater
    {
        public string Version { get; set; }
        public string DownloadUrl { get; set; }
    }
}
