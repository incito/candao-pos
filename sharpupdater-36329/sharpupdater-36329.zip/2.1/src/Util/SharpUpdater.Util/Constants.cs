﻿namespace CnSharp.Windows.Updater.Util
{
    public class Constants
    {
        public const string ReleaseConfigFileName = "ReleaseList.xml";
        public const string UpdaterExeName = "updater.exe";
    }
}