﻿namespace CnSharp.Delivery.VisualStudio.PackingTool
{
    public class FileListItem
    {
        public string Dir { get; set; }
        public bool IsFile { get; set; }
        public bool Selected { get; set; }
    }
}
