﻿using System;

namespace CnSharp.Windows.Updater.Util
{
    public class Constants
    {
        //[Obsolete]
        //public const string ReleaseConfigFileName = "ReleaseList.xml";

        public const string ManifestFileName = "manifest.xml";

        //public const string UpdaterExeName = "updater.exe";
    }
}